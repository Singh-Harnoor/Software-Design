package adapter;


import java.util.Enumeration;
import java.util.Iterator;


public class IteratorEnumeration implements Enumeration<Object> {
	
	private Iterator adaptee;
	
	public IteratorEnumeration(Iterator adaptee) {
		super();
		this.adaptee = adaptee;
	}
	

	@Override
	public boolean hasMoreElements() {
		return this.adaptee.hasNext();
	}

	@Override
	public Object nextElement() {
		return this.adaptee.next();
	}


	
	
}
