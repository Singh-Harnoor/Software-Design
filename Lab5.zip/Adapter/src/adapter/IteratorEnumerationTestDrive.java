package adapter;

import java.util.ArrayList;

public class IteratorEnumerationTestDrive {
	public static void main (String args[]) {
		
		ArrayList<String> fruits = new ArrayList<String>();
		fruits.add("Apple");
		fruits.add("Cherry");
		fruits.add("Banana");
		fruits.add("Strawberry");
		
		IteratorEnumeration e = new IteratorEnumeration(fruits.iterator());
		
		for(; e.hasMoreElements(); ) {
			System.out.println(e.nextElement());
		}
		System.out.println("==================================");
		fruits.add("Kiwi");
		fruits.remove("Strawberry");
		IteratorEnumeration ie = new IteratorEnumeration(fruits.iterator());
		for(; ie.hasMoreElements(); ) {
			System.out.println(ie.nextElement());
		}
		
	}
}
