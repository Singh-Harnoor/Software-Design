package lab2;
public class UnderstandInheritance {

	public static void main(String[] args) {
		// 6) Review class Square, understand what happens when we execute the following:
		// that is, which methods are called and when...
		
		System.out.println("Starting");
		
		Square s=new Square(); 
		// The line above calls the Square() constructor
		// which executes this("blue", 10, 100, 100); which calls
		// the Square(String c, int width, int x, int y) constructor
		// which executes super(c, width, width, x, y); which calls 
		// This calls the super (Rectangle) class' constructor 
		// Rectangle(String c, int width, int height, int x, int y)
		// This constructor executes super(c, x, y); 
		// This calls the constructor of the class Shape and runs its constructor
		// This sets the class variable to c = "blue", x = 100, and y = 100.
		// Then it returns back to Rectangle class' constructor.
		// After that it executes setWidth(width); and setHeight(height);
		// These methods sets the width and height variables of rectangle to 10.
		// Then the execution returns back to the Square class.

		System.out.println(s.toString());
		// The line above calls the toString method of class Square which it inherits from Rectangle class.
		// This executes the toString of the Rectangle class.
		// This executes the line String s = super.toString() + " Width: " + getWidth() + " Height: " + getHeight();
		// The super.toString method calls the toString method of Shape class.
		// which executes String s = "Color:" + color + " (" + x + "," + y + ")";
		// x and y values are 100.
		// Then execution returns back to Rectangle class. 
		// The returned string is added to the string above.
		// Width and Height is 10.
		// Then this string is returned from the toString method.
		s.setWidth(20);
		// The line above calls the method setWidth of the Square.
		// This calls the super method setWidth and setHeight with the argument 20
		// This changes the class variable values of width and height to 20. 
		s.setX(10);
		// This method is inherited by the shape class by the square class. 
		// This calls the method setPosition(x, y); with x = 10 and y = 100.
		// This then changes the variable values 
		
	}

}
