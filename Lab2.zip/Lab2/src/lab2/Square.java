package lab2;

public class Square extends Rectangle{
	//Default constructor
	public Square() {
		this("blue", 10, 100, 100);
	}
	
	//constructor with 4 parameters and calling the supper class method
	public Square(String c, int width, int x, int y) {
		super(c, width, width, x, y);
	}
	
	public void setWidth(int w) {
		super.setWidth(w);
		super.setHeight(w);
	}
}
