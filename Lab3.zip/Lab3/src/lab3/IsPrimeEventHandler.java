package lab3;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

public class IsPrimeEventHandler implements EventHandler<ActionEvent>{
	
	private TextField input;
	private TextField output;
	
	public IsPrimeEventHandler(TextField input, TextField output) {
		this.input = input;
		this.output = output;
	}
	
	@Override
	public void handle(ActionEvent event) {	
		
		try {
			int n=Integer.parseInt(this.input.getText());
			// n is a valid integer in here...
			Boolean prime = this.isPrime(n);
			if (prime == true) {
				PrimeTester.toPrint = "Yes";

			} else {
				PrimeTester.toPrint = "No";
			}
		} catch(NumberFormatException nfe){
			PrimeTester.toPrint = "Invalid Number";
			}
		
		
		this.output.setText(PrimeTester.toPrint);
		}
	
	private boolean isPrime(int n){
		for(int i=2;i<n;i++){
		if(n%i == 0) return false;
		}
		return true;
		}
	
}