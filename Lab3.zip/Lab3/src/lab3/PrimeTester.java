package lab3;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;


public class PrimeTester extends Application{
	public static String toPrint;
	
	@Override
	public void start(Stage arg0) throws Exception {
		
		TextField tfToWrite = new TextField();
		Button bIsPrime = new Button("Is Prime?");
		TextField tfToOutput = new TextField();
		tfToOutput.setEditable(false); 
		
		
		//Event 
		IsPrimeEventHandler isprime = new IsPrimeEventHandler(tfToWrite, tfToOutput);
	
		
		//Event with button link
		bIsPrime.addEventHandler(ActionEvent.ACTION, isprime);
		
			
		
		//Layout
		HBox root = new HBox();
		root.setPadding(new Insets(5));
		root.getChildren().addAll(tfToWrite, bIsPrime, tfToOutput);
		
		//Scene
		Scene scene = new Scene(root);
		
		//Stage
		Stage stage = new Stage();
		stage.setTitle("Prime Tester");
		stage.setScene(scene);
		stage.show();
		
	}
	
	public static void main(String[] args) {
		launch(args);
	}
	
	
	
	
} 