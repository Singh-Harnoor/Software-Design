package lab4;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class StockService extends Observable{
	
	private HashMap<String, Double> stocks;
	private ArrayList<StockTrader> users;
	//Attributes for the change in the price
	private String changedStock;
	private double price;
	
	public  StockService() {
		stocks = new HashMap<String, Double>();   //stocks mapped to their prices
		users = new ArrayList<StockTrader>(); //users mapped to list of stocks
	}
	
	public void addPrice(String stock, double price) {
		Double d = Double.valueOf(price);
		stocks.put(stock, d);
		this.changedStock = stock; 
		this.price = price;
		notifyObserver();
	}
	
	public double getPrice(String stock) {
		return (double) this.stocks.get(stock);
	}
	
	
	@Override
	public void register(Observer o) {
		this.users.add((StockTrader) o);
		StockTrader s = (StockTrader) o;
		s.service = this;	
	}

	@Override
	public void unregister(Observer o) {
		this.users.remove((StockTrader) o); 
		StockTrader s = (StockTrader) o;
		s.service = null;
	}

	@Override
	public void notifyObserver() {
		for(StockTrader u: users) {
			u.stockChanged(changedStock, price);
			u.update();
			 
		}
	}

}
