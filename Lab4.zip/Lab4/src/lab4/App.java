package lab4;

public class App {
	public static void main(String[] args) {
		StockService Trading = new StockService();
		StockTrader  u1	= new StockTrader("Joe");
		StockTrader  u2	= new StockTrader("Jim");
		StockTrader  u3	= new StockTrader("Jessy");
		Trading.register(u3);
		Trading.register(u2);
		Trading.register(u1);
		Trading.addPrice("Tesla", 800.0);
		Trading.addPrice("Apple", 155.0);
		Trading.addPrice("Tesla", 600);
		Trading.unregister(u2);
		Trading.unregister(u3);
		Trading.addPrice("Tesla", 900);
		Trading.addPrice("Apple", 200);
		double a = u1.getStockPrice("Apple");
		System.out.println("Apple:" + a + "\n");
		Trading.addPrice("MSFT", 100);
		System.out.println("Apple:" + u1.getStockPrice("MSFT"));
	}
}
