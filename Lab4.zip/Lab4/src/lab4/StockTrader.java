package lab4;


public class StockTrader implements Observer{
	
	private String name;
	public StockService service;
	private String StockChanged;
	private double price;
	
	public StockTrader(String name) {
		this.name = name;
		this.service = new StockService(); //no assigned service
	}
	
	public double getStockPrice(String stock) {
		return this.service.getPrice(stock);
	}
	
	public void stockChanged(String s, double price) {
		this.StockChanged = s;
		this.price = price;
	}
	
	@Override
	public void update() {
		//update by notifying
		System.out.println("Alert " +this.name+ "!  \n Price Changed: " + this.StockChanged + " $" + this.price +"\n");
	}

}
