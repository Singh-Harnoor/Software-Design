package lab4;

public interface Observer {
	
	void update();

}
