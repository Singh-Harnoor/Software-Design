package lab1;

public class TestPerson {

	/**
	 * The output is stored in the file MyTestPersonOut.txt
	 * Please make sure your output is identical to the provided output
	 * Keep in mind we will autotest your code by doing string matching.
	 */
	public static void main(String [] args){
		System.out.println("Testing a person interacting with a can of soda");
		Person p = new Person("Joe");
		SodaCan s2 = new SodaCan("Raspberry");
		System.out.println("Joe is sipping from the can of soda");
		p.sipFrom(s2);
		System.out.println(p);
		System.out.println(s2);
		System.out.println("Opening");
		s2.open();
		System.out.println("Joe is sipping from the can of soda");
		p.sipFrom(s2);
		System.out.println(p);
		System.out.println(s2);
		System.out.println("Joe is sipping from the can of soda");
		p.sipFrom(s2);
		System.out.println(p);
		System.out.println(s2);
		System.out.println("Joe is gulping from the can of soda");
		p.gulpFrom(s2);
		System.out.println(p);
		System.out.println(s2);
		System.out.println("Joe is gulping from the can of soda");
		p.gulpFrom(s2);
		System.out.println(p);
		System.out.println(s2);
		System.out.println("Joe is gulping from the can of soda");
		p.gulpFrom(s2);
		System.out.println(p);
		System.out.println(s2);
		System.out.println("Joe is gulping from the can of soda");
		p.gulpFrom(s2);
		System.out.println(p);
		System.out.println(s2);
		System.out.println("Joe is gulping from the can of soda");
		p.gulpFrom(s2);
		System.out.println(p);
		System.out.println(s2);
		System.out.println("Joe is gulping from the can of soda");
		p.gulpFrom(s2);
		System.out.println(p);
		System.out.println(s2);

	
		System.out.println("Joe is taking 4 gulps from a new can of soda");
		SodaCan s3 = new SodaCan("Coke");
		s3.open();
		p.gulpFrom(s3);
		p.gulpFrom(s3);
		p.gulpFrom(s3);
		p.gulpFrom(s3);
		System.out.println(p);
		System.out.println(s3);
	}
}

