package lab1;

/**
 * Capture a Can of Soda.
 * A Can of Soda has a type, amount (initially 250) and is initially closed.
 * Once opened, you can sip (take at most 10) or gulp (take at most 50) from
 * the can. Obviously, at all times, the amount of soda in the can is between 0 and 250.
 * An opened can can not be closed.
 */
public class SodaCan {
	//Class Parameters
	private String type;
	private boolean open;
	private int amount;
	

	/**
	 * Construct a new SodaCan of the specified type.
	 * The new can has 250 units in it, and is closed.
	 * @param t the type of soda, for example "RootBeer", "Coke", "Cherry"
	 */
	public SodaCan(String t) {
		this.type = t;
		this.open = false;
		this.amount = 250;
	}

     /**
         * open this SodaCan
      */
	public void open() {
		this.open = true;
	}

	/**
	 * @return whether this is open
	 */
	public boolean isOpen() {
		return this.open == true;
	}
	
     /**
         * remove up to 10cc of soda from this, provided this is open
         * @return the amount of soda actually removed
     */
	public int sip() {
		int qremoved = 0;
		if(this.open) { // if open, take a sip
			if(this.amount <= 10) {
				qremoved = this.amount;
				this.amount = 0; //all the remaining quantity removed in this sip
			}
			else { 
				qremoved = 10;
				this.amount -= 10;
			}
		}
		return qremoved; // if closed no soda removed from the can
	}

        /**
         * remove up to 50cc of soda from this, provided this is open
         * @return the amount of soda actually removed
         */
	public int gulp() {
		int qremoved = 0;
		if(this.open) { // if open, take a sip
			if(this.amount <= 50) {
				qremoved = this.amount;
				this.amount = 0; //all the remaining quantity removed in this sip
			}
			else { 
				qremoved = 50;
				this.amount -= 50;
			}
		}
		return qremoved; // if closed no soda removed from the can
	}

       /**
         * @return the amount of soda left in this
        */
	public int getAmount() {
		return this.amount;
	}

        /**
         * @return a string representation of this
         */
        public String toString(){
		String openString = (this.isOpen())?"open":"closed";
		return this.type+" "+openString+" "+this.amount;
        }
}

