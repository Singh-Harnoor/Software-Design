package lab1;

/**
 * The main method of this class plays out a scenario...
 * Jack has two cans of soda, RootBeer and GingerAle, 
 * Jill also has two cans, Cherry and Grape.
 * Jack opens his RootBeer first, and gives it to Jill.
 * Jill completely drinks the RootBeer. 
 * Jack asks her if she is still thirsty, Jill responds. 
 * Now Jill opens her Cherry soda and drinks it until
 * she is satisfied, then gives it to Jack. 
 * He takes a sip, but doesn't like it. 
 * Jill checks how much is left in her Cherry soda, but decides
 * not to drink any more. Jack asks Jill if he can try her Grape soda.
 * Jill gives it to Jack and he opens it.
 * Jack drinks about half of it, then stops and tells Jill how he now feels.
 * Finally, they check the amount available in all of the cans.
 */
public class Scenario {


}
