package lab1;

public class TestSodaCan {

	/**
	 * The output is stored in the file MyTestSodaCanOut.txt
	 * Please make sure your output is identical to the provided output
	 * Keep in mind we will autotest your code by doing string matching.
	 */

public static void main(String [] args){
	System.out.println("Testing a can of soda");

	SodaCan s1 = new SodaCan("RootBeer");
	System.out.println(s1);
	System.out.println("isOpen="+s1.isOpen());
	System.out.println("Sipping "+s1.sip());
	System.out.println(s1);
	System.out.println("Gulping "+s1.gulp());
	System.out.println(s1);
	System.out.println("Opening ");
	s1.open();
	System.out.println("isOpen="+s1.isOpen());
	System.out.println(s1);
	System.out.println("Sipping "+s1.sip());
	System.out.println(s1);
	System.out.println("Gulping "+s1.gulp());
	System.out.println(s1);
	System.out.println("Sipping "+s1.sip());
	System.out.println(s1);
	System.out.println("Gulping "+s1.gulp());
	System.out.println(s1);
	System.out.println("Gulping "+s1.gulp());
	System.out.println(s1);
	System.out.println("Gulping "+s1.gulp());
	System.out.println(s1);
	System.out.println("Gulping "+s1.gulp());
	System.out.println(s1);
	System.out.println("Sipping "+s1.sip());
	System.out.println(s1);
	System.out.println("Gulping "+s1.gulp());
	System.out.println(s1);
}
}

