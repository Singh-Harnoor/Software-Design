package lab1;

import static org.junit.Assert.*;

import org.junit.Test;


/*
 * This class contains a few tests, that may be used
 * for sanity checking. We will add more tests similar to
 * the existing tests, for marking your work.
 * 
 * Please feel free to add extra tests yourself, to make
 * sure you got it right.
 * 
 * This class will not be evaluated by your instructors.
 */
public class StudentTest {

	// This test checks if person name is set correctly
	@Test
	public void testName() {
		Person kyrel = new Person("Kyrel");
		String kyString = kyrel.toString();
		assertTrue("I am Kyrel, and I am very thirsty".equals(kyString));
	}
	
	// Person takes 5 gulps from unopened can. Very thirsty.
	@Test
	public void testUnOpened() {
		SodaCan s = new SodaCan("Roots");
		Person ilir = new Person("Ilir");

		ilir.gulpFrom(s);
		ilir.gulpFrom(s);
		ilir.gulpFrom(s);
		ilir.gulpFrom(s);
		ilir.gulpFrom(s);

		String ilirString = ilir.toString();
		assertTrue("I am Ilir, and I am very thirsty".equals(ilirString));
	}

}
